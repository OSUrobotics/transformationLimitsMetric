g++ -dynamiclib -I/opt/local/include/ geodesic_matlab_api.cpp -O3 -DNDEBUG -o geodesic.dylib
