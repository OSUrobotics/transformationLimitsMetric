This directory contains matlab functions written by others, which may be under
their own licenses.

To reduce clutter, licenses are listed in the comments beneath single file
programs.

Filenames should be original. If prototypes or filenames are strange, write a
wrapper and place in ../matrix, ../mesh, etc. where appropriate.

Some files are patched to work correctly or have more features, so careful when
updating: use diff.

