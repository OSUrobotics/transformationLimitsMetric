for use_adaptive=0:1
    for p = [200 400 1000]
        test_shape_meshing;
    end
end